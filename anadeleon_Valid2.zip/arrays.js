"use strict";

/*Friends Coffee Shopping Cart, Ana De Leon, 4/11/2021*/

var item = ["Brewed Coffee", "Iced Coffee", "Espresso", "Latte"];
var price = [4.25, 6.00, 4.50, 5.75];
var qty = [1,1,1,2];







